package net.jankenpoi.sudokuki.generator.suexg;

import net.jankenpoi.sudokuki.generator.SudokuGenerator;

public abstract class SuexgGenerator extends SudokuGenerator {

	public static SudokuGenerator getInstance() {
		return null;
	}
	
}
