RELEASEVERSION=1.2.2

java -Djava.library.path=. -jar sudokuki-"$RELEASEVERSION".jar -ui Swing
