?package(sudokuki):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="sudokuki" command="/usr/bin/sudokuki"
