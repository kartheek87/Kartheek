java -Djava.library.path=. -jar sudokuki-1.2.2.jar -ui Swing
