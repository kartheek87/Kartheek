    <?php
	include "connectioncreation.php";
?>
	<html>
    <head>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
          <!--Import materialize.css-->
          <link type="text/css" rel="stylesheet" href="css/materialize.min1.css"  media="screen,projection"/>

          <!--Let browser know website is optimized for mobile-->
          <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <nav>
        <div class="nav-wrapper">
          <a href="Home.html" class="brand-logo"><img src="a.png" width=92px; heigth=75px;/></a>
          <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li><a href="Home.html">Home</a></li>
            <li><a href="About.html">About</a></li>
            <li><a href="Stores.html">Stores</a></li>
            <li><a href="productmain.php">Products</a></li>
              <li><a href="cart.php">Cart</a></li>
            <li><a href="Donors.php">Donors</a></li>
            <li><a href="ContactUs.html">Contact Us</a></li>
           <li><a href="login.html">Login</a></li>

          </ul>
        </div>
      </nav>
           
      </head>
          <div class="row">
  <?php
$y = $_SERVER['QUERY_STRING'];
$q = "select * from `search` WHERE pname=\"$y\"";
$result = mysql_query($q);
if(!$result) {
die(mysql_error());
}
              else{
                  while($q8=mysql_fetch_array($result))
		{ 
	
	?>
	<div class="col s12 m7" >
          <div class="card">
            <div class="card-image">
              <img src="search/<?php echo $q8[2]; ?>.png" style="width:100%; height:30%; object-fit:contain;" >
              
            </div>
            <div class="card-content">
              <p Style='text-transform:capitalize; white-space: pre; text-align: center; color:#ffab40; font-family:roboto; font-size:18px;'> Product Name  :  <?php echo $q8[1];?></br>Product Brand  :  <?php echo $q8[2];?></br>Product Offer  :  <?php echo $q8[3];?> %
			  </p>
            </div>
            <div class="card-action">
             <a class="waves-effect waves-light btn">Add to Cart</a>
            </div>
          </div>
        </div>
	
	
	
<?php	
	} ?>
	<?php
		}	
	?>
			  
			  	
		
      </div>
	  
	  
   

<footer class="page-footer">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Food Savers</h5>
                <p class="grey-text text-lighten-4"></p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="Contactus.html">Contact Us     </a></li>
                  <li><a class="grey-text text-lighten-3" href="https://www.facebook.com/FOOD-Savers-1652558295005198/?skip_nax_wizard=true">Facebook       </a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Twitter        </a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2015 Food Savers Inc. All Rights Reserved.
        </div>
          </div>
        </footer>


      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
          <script type="text/javascript" src="js/materialize.min.js"></script>
      </html>