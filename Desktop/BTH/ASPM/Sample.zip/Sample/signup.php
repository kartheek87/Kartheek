<?php
	include "connectioncreation.php";
?>	
<?php
if(isset($_REQUEST['signupsub']))
{
	$un=$_REQUEST['username'];
	$fn=$_REQUEST['firstname'];
	$ln=$_REQUEST['lastname'];
	$e=$_REQUEST['email'];
	$date=$_REQUEST['date'];
	$male=$_REQUEST['gender'];
	$p=$_REQUEST['password'];
	$cp=$_REQUEST['password2'];
	$pno=$_REQUEST['pno'];
	$q="insert into sigup values ('$un','$fn','$ln','$e','$date','$male','$p','$cp','$pno')";
	$q4=mysql_query($q);
	if(!$q4)
		die(mysql_error());
	else
		echo"inserted";
	header("location:signin.php");
}
?>
