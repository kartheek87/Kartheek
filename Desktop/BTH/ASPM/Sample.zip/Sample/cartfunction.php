    <?php
	include "connectioncreation.php";

    session_start();
	$y=$_SERVER['QUERY_STRING'];
	$y1=explode('/',$y);
	$y2=$y1[0];
	$y3=$y1[1];
	$y4= $_SESSION['login_user'];
	$qry= "select * from search where pname='$y2' AND pbrand='$y3' ";
  
	$q4=mysql_query($qry);
	$q5=mysql_fetch_array($q4);
	if(!$q5)
	{
		die(mysql_error());
	}
	else
	{
		echo "";
		$ln1="insert into cart values('$q5[0]','$q5[1]','$q5[2]','$q5[3]')";
		$ln=mysql_query($ln1);
		if(!$ln)
	{
		die(mysql_error());
	}
	else
	{
		header("location:cart.php");
	}
	}

    
?>
	