<?php
    session_start();


        $v1 = "guest";
        $v2 = "1234";
$connection = mysql_connect("localhost", "root", "");
// To protect MySQL injection for Security purpose
// Selecting Database
$db = mysql_select_db("foodservice", $connection);
// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("select * from sigup where password='$v2' AND username='$v1'", $connection);
$rows = mysql_num_rows($query);
if ($rows == 1) {
$_SESSION['login_user']=$v1; // Initializing Session
 $_SESSION['start'] = time(); // Taking now logged in time.
            // Ending a session in 2 minutes from the starting time.
$_SESSION['expire'] = $_SESSION['start'] + (2*60);
header("location: Home.php"); // Redirecting To Other Page
} 
mysql_close($connection); // Closing Connection
?>